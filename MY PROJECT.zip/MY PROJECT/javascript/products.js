function add_products()
{
    document.getElementById("add_prod").style.visibility="visible";
}

